#!/bin/bash 
for file in /dev/ttyUSB*
do
 ./esptool.py --chip esp32 --port $file --flash_mode dio --flash_freq 40m --flash_size detect 0x10000 ota_data_initial.bin 0x1000 bootloader.bin 0x20000 at_customize.bin 0xf000 phy_init_data.bin 0x100000 esp-at.bin 0x8000 partitions_at.bin 
done
sleep 1
exit
